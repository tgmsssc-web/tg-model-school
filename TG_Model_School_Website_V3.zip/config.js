// SCHOOL MASTER DATA — replace only with verified public information.
const SCHOOL_CONFIG = {
  name: "TG MODEL SCHOOL & JUNIOR COLLEGE",
  address: "Lingapur, Dandepalli, Mancherial District, Telangana, India",
  academicYear: "2026–27",
  udiseCode: "UPDATE_FROM_OFFICIAL_RECORD",
  principal: "UPDATE",
  email: "UPDATE_OFFICIAL_EMAIL",
  phone: "UPDATE_OFFICIAL_PHONE"
};
