# TG Model School Website V3

## Structure
- `index.html` — public portal
- `admin.html` — administrator dashboard UI
- `config.js` — verified school master information
- `data.json` — notices, staff, enrolment, results and downloads
- `styles.css` — responsive design
- `app.js` — portal rendering
- `admin.js` — dashboard editing interface
- `backend-schema.sql` — production database blueprint

## Production deployment
Use an approved HTTPS hosting/server and a secure backend/database. Do not expose admin credentials in HTML/JS.
Recommended controls: HTTPS, strong password hashing, MFA where available, role-based access, audit logs, backups and authorised publication workflow.

## Privacy
Do not publish Aadhaar numbers, private addresses, personal/confidential student records, medical information, passwords or restricted information.
