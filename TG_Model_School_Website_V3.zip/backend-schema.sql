-- PostgreSQL-style production schema blueprint
CREATE TABLE schools (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  academic_year TEXT,
  udise_code TEXT,
  principal_name TEXT,
  official_email TEXT,
  official_phone TEXT,
  updated_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE staff (
  id UUID PRIMARY KEY,
  school_id UUID REFERENCES schools(id),
  name TEXT NOT NULL,
  designation TEXT NOT NULL,
  subject_role TEXT,
  public_contact TEXT,
  active BOOLEAN DEFAULT TRUE
);
CREATE TABLE notices (
  id UUID PRIMARY KEY,
  school_id UUID REFERENCES schools(id),
  title TEXT NOT NULL,
  category TEXT,
  notice_date DATE,
  file_url TEXT,
  published BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE TABLE results (
  id UUID PRIMARY KEY,
  school_id UUID REFERENCES schools(id),
  academic_year TEXT,
  examination TEXT,
  pass_percentage NUMERIC,
  published BOOLEAN DEFAULT FALSE
);
CREATE TABLE gallery (
  id UUID PRIMARY KEY,
  school_id UUID REFERENCES schools(id),
  title TEXT,
  image_url TEXT,
  published BOOLEAN DEFAULT FALSE
);
CREATE TABLE admin_users (
  id UUID PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'editor',
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT now()
);
